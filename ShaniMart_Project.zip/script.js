const products = [
  {id:1,name:"Shoes",price:1000},
  {id:2,name:"Watch",price:2000},
  {id:3,name:"Headphone",price:1500}
];

let cart = [];

function login(){
  const user = document.getElementById("username").value;
  if(user){
    document.getElementById("login").style.display="none";
    document.getElementById("store").style.display="block";
    loadProducts();
  }
}

function loadProducts(){
  const container = document.getElementById("products");
  container.innerHTML="";
  products.forEach(p=>{
    container.innerHTML += `
      <div class="product">
        <h4>${p.name}</h4>
        <p>₹ ${p.price}</p>
        <button onclick="add(${p.id})">Add</button>
      </div>
    `;
  });
}

function add(id){
  const item = products.find(p=>p.id===id);
  cart.push(item);
  updateCart();
}

function updateCart(){
  document.getElementById("count").innerText=cart.length;
  const cartBox=document.getElementById("cartItems");
  cartBox.innerHTML="";
  let total=0;
  cart.forEach(i=>{
    total+=i.price;
    cartBox.innerHTML+=`<div>${i.name} - ₹${i.price}</div>`;
  });
  document.getElementById("total").innerText=total;
}

function openCart(){
  document.getElementById("cart").style.display="block";
}

function closeCart(){
  document.getElementById("cart").style.display="none";
}
